package com.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.client.RestTemplate;

import com.assignment.config.ServiceConfig;
import com.assignment.exception.APIException;
import com.assignment.exception.InvalidRequestException;
import com.assignment.implementation.CacheService;
import com.assignment.implementation.WeatherService;

@RunWith(MockitoJUnitRunner.class)
public class WeatherServiceTest {

	private static final String SAMPLE_SUCCESS_RESPONSE = "{\n" + "    \"coord\": {\n" + "        \"lon\": 55.3047,\n"
			+ "        \"lat\": 25.2582\n" + "    },\n" + "    \"weather\": [\n" + "        {\n"
			+ "            \"id\": 800,\n" + "            \"main\": \"Clear\",\n"
			+ "            \"description\": \"clear sky\",\n" + "            \"icon\": \"01d\"\n" + "        }\n"
			+ "    ],\n" + "    \"base\": \"stations\",\n" + "    \"main\": {\n" + "        \"temp\": 312.21,\n"
			+ "        \"feels_like\": 319.21,\n" + "        \"temp_min\": 312.11,\n"
			+ "        \"temp_max\": 313.31,\n" + "        \"pressure\": 1000,\n" + "        \"humidity\": 42\n"
			+ "    },\n" + "    \"visibility\": 6000,\n" + "    \"wind\": {\n" + "        \"speed\": 7.72,\n"
			+ "        \"deg\": 120\n" + "    },\n" + "    \"clouds\": {\n" + "        \"all\": 9\n" + "    },\n"
			+ "    \"dt\": 1625465611,\n" + "    \"sys\": {\n" + "        \"type\": 1,\n" + "        \"id\": 7537,\n"
			+ "        \"country\": \"AE\",\n" + "        \"sunrise\": 1625448803,\n"
			+ "        \"sunset\": 1625497977\n" + "    },\n" + "    \"timezone\": 14400,\n" + "    \"id\": 292223,\n"
			+ "    \"name\": \"Dubai\",\n" + "    \"cod\": 200\n" + "}";

	@InjectMocks
	private WeatherService weatherService;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private CacheService cacheService;

	@Mock
	private ServiceConfig config;

	@Before
	public void setMocks() throws Exception {
	}

	@Test(expected = InvalidRequestException.class)
	public void testgetWeatherResponseError() throws APIException {

		String response = weatherService.getWeatherResponseFromApi(null, null, null);
		assertNull(response);
	}

	@Test
	public void testgetWeatherResponseFromApiByCityError() throws APIException {

		String response = weatherService.getWeatherResponseFromApi("Dubai,AE", "", "");
		assertNull(response);
	}

	@Test
	public void testgetWeatherResponseFromApiByCitySuccess() throws APIException {

		when(cacheService.getWeatherData(Mockito.any(), Mockito.any(), anyString(), anyString()))
				.thenReturn(SAMPLE_SUCCESS_RESPONSE);

		String response = weatherService.getWeatherResponseFromApi("Dubai,AE", "", "");
		assertNotNull(response);
		assertEquals(SAMPLE_SUCCESS_RESPONSE, response);
	}

	@Test
	public void testgetWeatherResponseFromApiBylatLongSuccess() throws APIException {

		when(cacheService.getWeatherData(Mockito.any(), Mockito.any(), anyString(), anyString()))
				.thenReturn(SAMPLE_SUCCESS_RESPONSE);

		String response = weatherService.getWeatherResponseFromApi("", "25.12", "55.23");
		assertNotNull(response);
		assertEquals(SAMPLE_SUCCESS_RESPONSE, response);
	}

}