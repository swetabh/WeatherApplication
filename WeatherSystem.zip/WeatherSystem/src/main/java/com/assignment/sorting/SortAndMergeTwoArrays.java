package com.assignment.sorting;

import static java.util.Arrays.sort;
import static java.util.Arrays.stream;

public class SortAndMergeTwoArrays {

	public static void main(String args[]) {

		int[] array1 = { 1, 3, 5, 7, 8 };
		int[] array2 = { 2, 4, 6, 9, 10 };
		int[] sortedArray = sortArrays(array1, array2);

		System.out.println("Sorted and Merged Array is :");
		stream(sortedArray).forEach(s -> System.out.print(s + " "));
	}

	public static int[] sortArrays(int[] array1, int[] array2) {

		sort(array1);
		sort(array2);
	
		int arrayLen1 = array1.length;
		int arrayLen2 = array2.length;
		int finalArrLen = arrayLen1 + arrayLen2;

		int[] finalArr = new int[finalArrLen];
		int i = 0;
		int j = 0;
		int k = 0;
		while (i < arrayLen1 && j < arrayLen2) {
			if (array1[i] < array2[j]) {
				finalArr[k++] = array1[i++];
			} else {
				finalArr[k++] = array2[j++];
			}
		}
		while (i < arrayLen1) {
			finalArr[k++] = array1[i++];
		}
		while (j < arrayLen2) {
			finalArr[k++] = array2[j++];
		}
		return finalArr;
	}

}