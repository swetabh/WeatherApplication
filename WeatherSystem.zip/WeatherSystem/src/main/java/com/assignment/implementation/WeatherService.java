package com.assignment.implementation;

import static org.slf4j.LoggerFactory.getLogger;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.exception.APIException;
import com.assignment.exception.InvalidRequestException;

@Service
public class WeatherService {

	private static final Logger log = getLogger(WeatherService.class);

	@Autowired
	private CacheService cacheService;

	/***
	 * Get the weather details by user search params
	 * 
	 * @param cityCountry
	 * @param latitude
	 * @param longitude
	 * @return
	 * @throws APIException
	 */
	public String getWeatherResponseFromApi(String cityCountry, String latitude, String longitude) throws APIException {

		if ((cityCountry == null || "".equalsIgnoreCase(cityCountry) || cityCountry.indexOf(",") == -1)
				&& (latitude == null || "".equalsIgnoreCase(latitude))
				&& (longitude == null || "".equalsIgnoreCase(longitude))) {
			log.error("Missing parameters for getWeatherResponseFromApi api : cityCountry {} latitude {} longitude {}",
					cityCountry, latitude, longitude);
			throw new InvalidRequestException();
		}
		String city = null;
		String country = null;
		if (cityCountry != null && !"".equalsIgnoreCase(cityCountry)) {
			String[] cityCountryArr = cityCountry.split(",");
			city = cityCountryArr[0];
			country = cityCountryArr[1];
		}
		return cacheService.getWeatherData(city, country, latitude, longitude);
	}

}