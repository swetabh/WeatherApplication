package com.assignment.implementation;

import com.assignment.exception.APIException;

public interface CacheService {

    String getWeatherData(String city, String country, String latitude, String longitude) throws APIException;
    
    void resetCachedDataByCacheName(String cacheName);

	void resetAllCachedData();
}