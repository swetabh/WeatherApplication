package com.assignment.implementation;

import static org.slf4j.LoggerFactory.getLogger;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.assignment.config.ServiceConfig;
import com.assignment.exception.APIException;

public class CacheServiceImpl implements CacheService {

	private static final Logger log = getLogger(CacheServiceImpl.class);

	@Autowired
	private CacheManager cacheManager;

	@Autowired
	private ServiceConfig config;

	@Autowired
	private RestTemplate restTemplate;

	/***
	 * Get the weather data for user criteria and cache it
	 */
	@Override
	@Cacheable(value = "weatherDataList", key = "{#city, #country, #latitude, #longitude}")
	public String getWeatherData(String city, String country, String latitude, String longitude) throws APIException {

		try {
			StringBuilder builder = new StringBuilder();
			builder.append(config.getUrl());
			if (city != null) {
				builder.append("q=").append(city);
			} else {
				builder.append("lat=").append(latitude).append("&lon=").append(longitude);
			}
			builder.append("&appid=").append(config.getAppid());
			final HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			final HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
			return restTemplate.exchange(builder.toString(), HttpMethod.GET, entity, String.class).getBody();
		} catch (Exception ex) {
			log.error("Error in calling getWeatherResponseFromApi api for city {} latitude {} longitude {}", city,
					latitude, longitude);
			throw new APIException("Exception occurred while calling getWeatherResponseFromApi api ", ex);
		}
	}

	/***
	 * Reset the cache with cache name
	 * 
	 * @param cacheName
	 */
	@Override
	public void resetCachedDataByCacheName(String cacheName) {
		try {
			log.info("resetCachedDataByCacheName initiated for cacheName : {}", cacheName);
			cacheManager.getCache(cacheName).clear();
			log.info("Cache with name :{} reset successfully", cacheName);
		} catch (Exception e) {
			log.error("Error in Cache Reset for cache name {} : {} ", cacheName, e.getMessage());
		}
	}

	/***
	 * Reset all cached data
	 */
	@Override
	public void resetAllCachedData() {

		try {
			log.info("resetAllCachedData initiated");
			cacheManager.getCacheNames().stream().forEach(cacheName -> cacheManager.getCache(cacheName).clear());
			log.info("All Cache data reset successfully");
		} catch (Exception e) {
			log.error("Error in all Cache Reset Available cacheNames :{}", cacheManager.getCacheNames());
		}
	}

}