package com.assignment.scheduler;

import static com.assignment.config.ServiceConfig.CRON_EXPRESSION;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class CacheResetScheduler {

	@Autowired
	private CacheManager cacheManager;

	/***
	 * Reset the cache every 2 hours
	 */
	@Scheduled(fixedDelay = CRON_EXPRESSION)
	public void scheduleCacheDataReload() {

		cacheManager.getCacheNames().stream().forEach(cacheName -> cacheManager.getCache(cacheName).clear());

	}

}