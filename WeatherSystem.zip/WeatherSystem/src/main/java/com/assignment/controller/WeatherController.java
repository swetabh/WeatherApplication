package com.assignment.controller;

import static org.slf4j.LoggerFactory.getLogger;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.exception.APIException;
import com.assignment.implementation.WeatherService;

@RestController
@RequestMapping(path = "/api/weather", produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
public class WeatherController {

	private static final Logger log = getLogger(WeatherController.class);

	@Autowired
	private WeatherService weatherService;

	/***
	 * Get the weather details by city and Country
	 * 
	 * @param cityCountry
	 * @return
	 * @throws APIException
	 */
	@GetMapping(path = "/getbycitycountry")
	public String getWeatherByCityAndCountry(@RequestParam(name = "citycountry", required = true) String cityCountry)
			throws APIException {

		log.info("getbycitycountry api called");
		String weather = weatherService.getWeatherResponseFromApi(cityCountry, null, null);

		log.info("The Weather for city country {} is {}", cityCountry, weather);
		return weather;
	}

	/***
	 * Get the weather details by latitude and longitude
	 * 
	 * @param latitude
	 * @param longitude
	 * @return
	 * @throws APIException
	 */
	@GetMapping(path = "/getbylatlon")
	public String getWeatherByLatLong(@RequestParam(name = "lat", required = true) String latitude,
			@RequestParam(name = "lon", required = true) String longitude) throws APIException {

		log.info("getbylatlon api called");
		String weather = weatherService.getWeatherResponseFromApi(null, latitude, longitude);

		log.info("The Weather for latitide {} and longitude {} is : {}", latitude, longitude, weather);
		return weather;
	}

}