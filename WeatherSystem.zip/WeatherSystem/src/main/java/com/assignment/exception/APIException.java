package com.assignment.exception;

public class APIException extends Exception {

	private static final long serialVersionUID = -5808382659725676781L;

	public APIException() {
		super();
	}

	public APIException(String message, Exception e) {
		super(message, e);
	}

	public APIException(String message) {
		super(message);
	}
}